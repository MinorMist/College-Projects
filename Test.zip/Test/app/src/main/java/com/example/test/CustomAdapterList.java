package com.example.test;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class CustomAdapterList extends BaseAdapter {

    Context context;
    String names[];
    int images[];
    LayoutInflater inflter;
    public CustomAdapterList(Context context, String[] nameLst, int[] images) {
        this.context = context;
        this.names = nameLst;
        this.images = images;
        inflter = (LayoutInflater.from(context.getApplicationContext()));
    }

    @Override
    public int getCount() {
        return names.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = inflter.inflate(R.layout.customlistlayout2, null);
        TextView name = (TextView) view.findViewById(R.id.nameField);
        ImageView image = (ImageView) view.findViewById(R.id.icon);
        name.setText(names[i]);
        image.setImageResource(images[i]);
        return view;
    }
}
