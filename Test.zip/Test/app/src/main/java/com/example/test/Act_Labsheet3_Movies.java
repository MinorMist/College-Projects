package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RatingBar;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class Act_Labsheet3_Movies extends AppCompatActivity {

    RatingBar mov1Bar, mov2Bar, mov3Bar;
    EditText emailTf,dateTf;
    Button submitBtn;
    ImageButton dateBtn;
    final Calendar myCalendar= Calendar.getInstance();
    String date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act_labsheet3_movies);

        mov1Bar=(RatingBar) findViewById(R.id.mov1rBar);
        mov2Bar=(RatingBar) findViewById(R.id.mov2rBar);
        mov3Bar=(RatingBar) findViewById(R.id.mov3rBar);

        dateBtn=(ImageButton) findViewById(R.id.dateBtn);
        dateTf=(EditText) findViewById(R.id.dateTxt);
        dateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDatePickerDialog();
            }

            private void openDatePickerDialog() {
                Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(Act_Labsheet3_Movies.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int selectedYear, int selectedMonth, int selectedDay) {
                        date = selectedYear + "/" + (selectedMonth + 1) + "/" + selectedDay;
                        dateTf.setText(date);
                    }
                }, year, month, day);

                datePickerDialog.show();
            }
        });

        emailTf=(EditText) findViewById(R.id.emailTxt);
        submitBtn=(Button) findViewById(R.id.subBtn);
        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float r1=mov1Bar.getRating();
                float r2=mov2Bar.getRating();
                float r3=mov3Bar.getRating();
                String avg=String.format("%.2f",(r1+r2+r3)/3);
                String email=emailTf.getText().toString();
                String str="\nEmail: "+email+"\nDate : "+dateTf.getText().toString()+"\n\nTitanic: "+String.valueOf(r1)+"\nPOTC: "+String.valueOf(r2)+"\nDune: "+String.valueOf(r3)+"\n\nAverage rating: "+avg;
                displayRating(str);
            }

            private void displayRating(String str) {
                ExampleDialog ed=new ExampleDialog("Rating result", str);
                ed.show(getSupportFragmentManager(),"MovieRating");
            }
        });
    }
}