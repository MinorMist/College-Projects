package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import java.util.ArrayList;

public class Act_Labsheet1 extends AppCompatActivity {

    Button backbtn,toastBtn,doneBtn;
    EditText tosTxt,nameTxt;
    RadioButton MaleRb,FemaRb;
    CheckBox JavaCb,HtmlCb,PythonCb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        backbtn=(Button)findViewById(R.id.backBtn);
        doneBtn=(Button)findViewById(R.id.doneBtn);
        toastBtn=(Button)findViewById(R.id.toastBtn);
        tosTxt= (EditText) findViewById(R.id.tfToast);
        nameTxt = (EditText) findViewById(R.id.tfName);
        MaleRb=(RadioButton) findViewById(R.id.rbMale);
        FemaRb=(RadioButton) findViewById(R.id.rbFemale);
        JavaCb=(CheckBox) findViewById(R.id.cbJava);
        PythonCb=(CheckBox) findViewById(R.id.cbPython);
        HtmlCb=(CheckBox) findViewById(R.id.cbHTMLCSS);


        backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        toastBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str= (String) tosTxt.getText().toString();
                Toast tos2=Toast.makeText(getApplicationContext(),str, Toast.LENGTH_SHORT);
                tos2.show();
            }
        });

        doneBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name=(String) nameTxt.getText().toString();
                String gender= (String) findGender();
                String sub=(String) findSubject();
                String msg="Name: "+name+"\nGender: "+gender+"\nSubject: "+sub;
                ExampleDialog ed=new ExampleDialog("Form result",msg);
                ed.show(getSupportFragmentManager(),"Example");
            }
        });
    }

    private String findSubject() {
        ArrayList <String> SL=new ArrayList<String>();
        if(JavaCb.isChecked()){
            SL.add("Java");
        }
        if(PythonCb.isChecked()){
            SL.add("Python");
        }
        if(HtmlCb.isChecked()) {
            SL.add("HTML/CSS");
        }
        String str=String.join(", ",SL);
        return str;
    }

    private String findGender() {
        if(MaleRb.isChecked()){
            return "Male";
        } else if (FemaRb.isChecked()) {
            return "Female";
        }
        return "";
    }
}