package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Act_Labsheet2_display extends AppCompatActivity {

    EditText displayTf;
    Button backBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act_labsheet2_display);

        displayTf=(EditText) findViewById(R.id.displayTf);
        Bundle bun=getIntent().getExtras();
        String name,email,phno;
        name=bun.getString("uname");
        email=bun.getString("email");
        phno=bun.getString("phno");
        displayTf.setText("Name: "+name+"\nPhone no: "+phno+"\nEmail: "+email);

        backBtn=(Button) findViewById(R.id.backBtn);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }
}