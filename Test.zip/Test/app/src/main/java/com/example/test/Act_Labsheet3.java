package com.example.test;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Act_Labsheet3 extends AppCompatActivity {

    Spinner aniSp;
    Button aniBtn,starBtn,pbarBtn,movieBtn;
    ProgressBar pBar;
    RatingBar rBar;
    private Handler hdlr = new Handler();
    private int i=0;

    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act_labsheet3);

        Spinner aniSp=(Spinner) findViewById(R.id.aniSp);
        ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(getApplicationContext(),R.array.names_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        aniSp.setAdapter(adapter);

        movieBtn=(Button) findViewById(R.id.movieBtn);
        movieBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(), Act_Labsheet3_Movies.class);
                startActivity(i);
            }
        });

        aniBtn=(Button) findViewById(R.id.aniBtn);
        aniBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),aniSp.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();
            }
        });

        rBar =(RatingBar) findViewById(R.id.ratingBar);
        starBtn=(Button) findViewById(R.id.starBtn);
        starBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String rate=String.valueOf(rBar.getRating());
                Toast.makeText(getApplicationContext(), rate , Toast.LENGTH_SHORT).show();
            }
        });

        pBar=(ProgressBar) findViewById(R.id.progressBar);
        int progress=0;
        pbarBtn=(Button) findViewById(R.id.pbarBtn);
        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                // This code will be executed on the main UI thread
                if (msg.what == 1) {
                    Toast.makeText(Act_Labsheet3.this, "Done", Toast.LENGTH_SHORT).show();
                    pBar.setProgress(0);
                    pbarBtn.setEnabled(true);
                }
                return true;
            }
        });

        pbarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pbarBtn.setEnabled(false);
                i = pBar.getProgress();
                new Thread(new Runnable() {
                    public void run() {
                        while (i < 100) {
                            i += 1;
                            // Update the progress bar and display the current value in text view
                            hdlr.post(new Runnable() {
                                public void run() {
                                    pBar.setProgress(i);
                                }
                            });
                            try {
                                // Sleep for 100 milliseconds to show the progress slowly.
                                Thread.sleep(50);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        Message message = handler.obtainMessage(1);
                        handler.sendMessage(message);
                    }
                }).start();
            }
        });
    }
}