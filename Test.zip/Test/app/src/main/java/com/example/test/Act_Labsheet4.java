package com.example.test;

import static com.example.test.R.id.nameLst;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;


public class Act_Labsheet4 extends AppCompatActivity {

    ListView nameLst,custNameList;
    Button recBtn;
    String[] name_array = {"Achyut", "Akshay", "Afsal", "Arjun", "Sandeep", "Sanjay", "Mishra", "Siddharth", "Deepak", "Sai", "Sujith", "JJ", "Shashwat", "Vishnu", "Thomas"};
    int[] images={R.drawable.avatar1,R.drawable.avatar2,R.drawable.avatar3,R.drawable.avatar4,R.drawable.avatar5,R.drawable.avatar6,R.drawable.avatar7,R.drawable.avatar8,R.drawable.avatar9,R.drawable.avatar10,R.drawable.avatar11,R.drawable.avatar12,R.drawable.avatar13,R.drawable.avatar14,R.drawable.avatar15};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act_labsheet4);

        recBtn=(Button)findViewById(R.id.recycleviewBtn);
        recBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Act_Labsheet4.this, Act_Labsheet4_RecycleView.class);
                startActivity(i);
            }
        });

        nameLst = (ListView) findViewById(R.id.nameLst);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.customlistlayout, R.id.textView11, name_array) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView textView = view.findViewById(R.id.textView11);
                // You can customize the item view here, if needed
                textView.setText(getItem(position));
                return view;
            }
        };

        // Set the adapter for the ListView
        nameLst.setAdapter(adapter);

        custNameList=(ListView) findViewById(R.id.custNameLst);
        CustomAdapterList customAdapter = new CustomAdapterList(getApplicationContext(), name_array, images);
        custNameList.setAdapter(customAdapter);
    }
}