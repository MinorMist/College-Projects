package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Act_Labsheet2 extends AppCompatActivity {

    EditText nameTf, phoneTf, emailTf;
    Button subBtn,sandBtn,webBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        subBtn=(Button) findViewById(R.id.submitBtn);
        subBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nameTf=(EditText) findViewById(R.id.tfName);
                phoneTf=(EditText) findViewById(R.id.tfPhone);
                emailTf=(EditText) findViewById(R.id.tfEmail);

                String uname= nameTf.getText().toString();
                String phno=phoneTf.getText().toString();
                String email=emailTf.getText().toString();

                Intent i=new Intent(Act_Labsheet2.this, Act_Labsheet2_display.class);
                Bundle bun= new Bundle();
                bun.putString("uname",uname);
                bun.putString("phno",phno);
                bun.putString("email",email);
                i.putExtras(bun);
                startActivity(i);
            }
        });

        sandBtn=(Button) findViewById(R.id.sandBtn);
        sandBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Act_Labsheet2.this, Act_Labsheet2_Sandwich.class);
                startActivity(i);
            }
        });

        webBtn=(Button) findViewById(R.id.websiteBtn);
        webBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse("http://www.github.com/minormist"));
                startActivity(i);
            }
        });
    }
}