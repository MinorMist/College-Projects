package com.example.test;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button lab1btn,lab2btn,lab3btn,lab4btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lab1btn=(Button)findViewById(R.id.lab1Btn);
        lab2btn=(Button)findViewById(R.id.lab2Btn);
        lab3btn=(Button)findViewById(R.id.lab3Btn);
        lab4btn=(Button)findViewById(R.id.lab4Btn);

        lab1btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainActivity.this, Act_Labsheet1.class);
                startActivity(i);
            }
        });
        lab2btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainActivity.this, Act_Labsheet2.class);
                startActivity(i);
            }
        });
        lab3btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainActivity.this, Act_Labsheet3.class);
                startActivity(i);
            }
        });
        lab4btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainActivity.this, Act_Labsheet4.class);
                startActivity(i);
            }
        });
    }
}