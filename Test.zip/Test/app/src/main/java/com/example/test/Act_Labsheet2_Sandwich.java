package com.example.test;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;

public class Act_Labsheet2_Sandwich extends AppCompatActivity {

    EditText nameTf;

    AutoCompleteTextView drinkTf;
    TextView dateTf,timeTf;
    CheckBox mushCb,onionCb,jaleCb,pannCb;
    RadioGroup radioGrp;
    RadioButton fifRb,thiRb,selectedRb;
    String[] d_arr={"fanta","pepsi","7up"};
    Button orderBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act_labsheet2_sandwich);

        nameTf=(EditText) findViewById(R.id.nameTf);
        drinkTf=(AutoCompleteTextView) findViewById(R.id.drinkTf);
        dateTf=(TextView) findViewById(R.id.dateTf);
        radioGrp=(RadioGroup) findViewById(R.id.radioGroup2);
        timeTf=(TextView) findViewById(R.id.timeTf);
        mushCb=(CheckBox) findViewById(R.id.Cbmush);
        onionCb=(CheckBox) findViewById(R.id.Cbonion);
        jaleCb=(CheckBox) findViewById(R.id.CbJale);
        pannCb=(CheckBox) findViewById(R.id.CbPaneer);
        fifRb=(RadioButton) findViewById(R.id.lengthfifRb);
        thiRb=(RadioButton) findViewById(R.id.lengththiRb);

        dateTf.setText(getDate());
        timeTf.setText(getTime());

        ArrayAdapter<String> adapter=new ArrayAdapter<String>(Act_Labsheet2_Sandwich.this, android.R.layout.simple_dropdown_item_1line,d_arr);
        drinkTf.setThreshold(1);
        drinkTf.setAdapter(adapter);


        orderBtn=(Button) findViewById(R.id.ordBtn);
        orderBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name=nameTf.getText().toString();
                String drink=drinkTf.getText().toString();
                String bread,drinks,toppings;
                int b_rate=getBreadRate();
                int t_rate=getToppingsRate();
                int d_rate=getDrinkRate();
                bread=getBread();
                toppings=getToppings();
                drinks=getDrinks();
                Sandwich_dialog dialog=new Sandwich_dialog(name,getDate(),getTime(),bread,drinks,toppings,b_rate,t_rate,d_rate);
                dialog.show(getSupportFragmentManager(),"Dialog");
            }

            private String getDrinks() {
                if(getDrinkRate()>0){
                    return drinkTf.getText().toString();
                }
                return "Unavailable";
            }
            private String getToppings() {
                ArrayList<String> top=new ArrayList<String>();
                if(pannCb.isChecked()){
                    top.add("Paneer");
                }
                if(mushCb.isChecked()){
                    top.add("Mushroom");
                }
                if(onionCb.isChecked()){
                    top.add("Onion");
                }
                if(jaleCb.isChecked()){
                    top.add("Jalepeno");
                }
                if(top.isEmpty()){
                    return "No toppings";
                }
                return String.join(", ",top);
            }
            private String getBreadLength() {
                if(fifRb.isChecked()){
                    return "15 cm";
                }
                else if (thiRb.isChecked()) {
                    return "30 cm";
                }
                return "Not selected";
            }
            private int getDrinkRate() {
                String d=drinkTf.getText().toString();
                boolean flag=false;
                for(String ele:d_arr){
                    if(ele.equalsIgnoreCase(d)){
                        flag=true;
                        break;
                    }
                }
                if(flag){
                    return 40;
                }
                return 0;
            }
            private int getToppingsRate() {
                int r=0;
                if(pannCb.isChecked()){
                    r+=50;
                }
                if(mushCb.isChecked()){
                    r+=50;
                }
                if(onionCb.isChecked()){
                    r+=30;
                }
                if(jaleCb.isChecked()){
                    r+=30;
                }
                return r;
            }
            private int getBreadRate() {
                if(fifRb.isChecked()){
                    return 100;
                }
                else if (thiRb.isChecked()) {
                    return 200;
                }
                return 0;
            }
        });
    }

    private String getTime() {
        String currentTime = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
        return currentTime;
    }

    private String getBread() {
        int selectedRbId=radioGrp.getCheckedRadioButtonId();
        selectedRb=(RadioButton) findViewById(selectedRbId);
        if(selectedRbId==-1)
            return "Nothing selected";
        else
            return selectedRb.getText().toString();
    }

    private String getDate() {
        String currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        return currentDate;
    }
}