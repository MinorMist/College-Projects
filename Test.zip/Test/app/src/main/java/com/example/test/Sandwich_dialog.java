package com.example.test;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

public class Sandwich_dialog extends AppCompatDialogFragment {
    int b_rate,t_rate,d_rate,tot;
    String name,bread,drinks,toppings,date,time;
    Sandwich_dialog(String name,String date,String time, String b,String d,String t,int br,int tr,int dr){
        this.name=name;
        this.date=date;
        this.time=time;
        bread=b;
        drinks=d;
        toppings=t;
        b_rate=br;
        t_rate=tr;
        d_rate=dr;
        tot=b_rate+t_rate+d_rate;
    }
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder= new AlertDialog.Builder(getActivity());
        builder.setTitle("Order details: "+name)
                .setMessage("\nDate: "+date+"\nTime: "+time+"\n\nBread: "+b_rate+"\n"+bread+"\n\nDrinks: "+d_rate+"\n"+drinks+"\n\nToppings: "+t_rate+"\n"+toppings+"\n\nTotal: "+tot)
                .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
        return builder.create();
    }
}